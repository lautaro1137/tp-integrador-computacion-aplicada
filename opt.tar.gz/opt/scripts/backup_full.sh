#!/usr/bin/env bash
set -euo pipefail

script_respaldo() {
  origen="$1"
  destino="$2"
  fecha=$(date +%Y%m%d)
  nombre="$(basename "$origen")_bkp${fecha}.tar.gz"

  if [[ ! -d "$origen" ]]; then
    echo "El directorio $origen no existe!"
    return 1
  fi

  if ! mountpoint -q "$destino"; then
    echo "Destino $destino no montado"
    return 1
  fi

  tar -czf "$destino/$nombre" "$origen"
}

case "${1:-}" in
  logs)
    script_respaldo "/var/log" "/backup_dir"
    ;;
  dir)
    script_respaldo "/www_dir" "/backup_dir"
    ;;
  -help|-h|--help)
    echo "Uso: $0 [logs|dir]"
    echo "logs: backupear /var/log a /backup_dir"
    echo "dir: backupear /www_dir a /backup_dir"
    exit 0
    ;;
  *)
    echo "Opción inválida. Usa 'logs' o 'dir' o '-help'"
    exit 1
    ;;
esac
